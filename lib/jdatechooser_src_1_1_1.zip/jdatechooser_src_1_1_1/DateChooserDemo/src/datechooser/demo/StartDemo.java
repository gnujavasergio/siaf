/*
 * StartDemo.java
 *
 * Created on 15 ������� 2006 �., 9:20
 *
 */

package datechooser.demo;

import javax.swing.UIManager;

/**
 *
 * @author Vadik
 */
public class StartDemo {
    
    public static void main(String[] args) {
       StartFrame fr = new StartFrame();
       fr.setVisible(true);
    }
    
}
