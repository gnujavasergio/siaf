/*
 * DemoPanelListener.java
 *
 * Created on 7 ������� 2006 �., 22:04
 *
 */

package datechooser.demo.steps;

/**
 *
 * @author Vadim
 */
public interface DemoPanelListener {
    void onStep();
}
